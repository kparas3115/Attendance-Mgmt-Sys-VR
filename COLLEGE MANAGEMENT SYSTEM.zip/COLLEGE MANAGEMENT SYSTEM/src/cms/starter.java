package cms;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class starter extends JFrame implements ActionListener {

    JButton login;

    starter() {
        setSize(1000, 600);
        JLabel l1 = new JLabel("SIES GST Nerul");
        l1.setBounds(380, -10, 470, 270);
        l1.setFont(new Font("Tahoma", Font.BOLD, 32));
        add(l1);

        login = new JButton("Login");
        login.setBounds(750, 450, 180, 80);
        login.addActionListener(this);
        add(login);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("images/banner1.jpg"));
        JLabel i3 = new JLabel(i1);
        i3.setBounds(0,0,1000,600);
        add(i3);


        setLayout(null);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==login){
           new login();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new starter();
    }
}
