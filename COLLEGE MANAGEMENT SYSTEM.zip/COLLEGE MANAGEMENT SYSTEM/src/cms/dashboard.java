package cms;

import javax.swing.*;
import java.awt.*;

public class dashboard extends JFrame {
    JMenuBar mb;
    JButton  SE , TE , logout;
    dashboard(){
        setSize(1600 ,1000);

        mb = new JMenuBar();
        mb.setBounds(0,0,150 , 750);
        mb.setLayout(new GridLayout(3, 1,40 ,40 ));
        mb.setBackground(Color.blue);
        mb.setBackground(Color.getColor("gray",40));

        SE = new JButton("SE AIML");
        mb.add(SE);

        TE = new JButton("TE AIML");
        mb.add(TE);

        logout = new JButton("Log Out");
        mb.add(logout);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("images/AMS.jpg"));
        JLabel i3 = new JLabel(i1);
        i3.setBounds(0,-100,1600,1000);
        add(i3);


        add(mb);


        setLayout(null);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {

        new dashboard();

    }
}
